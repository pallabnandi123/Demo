// Example C code (xc_functions.c)
#include <stdio.h>
#include <stdlib.h>

// Define a C structure
typedef struct {
    int number;
    // Add more fields as needed
} FuncInfo;

// Example C function
int xc_func_info_get_number(void *info_ptr) {
    // Cast the void pointer to the structure type
    FuncInfo *info = (FuncInfo *)info_ptr;

    // Return the number field of the structure
    return info->number;
}
