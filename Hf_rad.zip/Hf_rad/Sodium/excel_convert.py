import pandas as pd

# Read data file
data = pd.read_csv('data.dat', delimiter=' ')  # Assuming space-delimited, adjust delimiter as needed

# Write to Excel
excel_file = 'data.xlsx'
data.to_excel(excel_file, index=False)  # Index is set to False to avoid writing row numbers as a separate column

print(f"Data has been written to {excel_file}")

