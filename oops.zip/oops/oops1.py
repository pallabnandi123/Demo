class Email:
	pass

e1=Email()
e2=Email()

print(type(e1))
