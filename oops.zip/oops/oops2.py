class Employee:
	company_name="infosys"
	def __init__(self,nm,sal):
		self.name=nm
		self.salary=sal #attributes
	@classmethod
	def get_company_name(cls):
		cls.company_name="TCS"
		print(f"company name is:",cls.company_name)
e1=Employee("jay",24000)
e2=Employee("vijay",26000)

Employee.get_company_name()
print(e2.company_name)
print(e1.__dict__)
print(e1.salary)
print(getattr(e1,'name'))
setattr(e2,'salary',25000)
print(e2.__dict__)
#delattr(e2,'age')
print(e2.__dict__)
print(hasattr(e1,'name'))
print(Employee.__doc__)
print(Employee.__name__)
print(Employee.__module__)
print(isinstance(e1,Employee))


